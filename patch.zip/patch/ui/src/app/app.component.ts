import { Component, Input, OnInit ,ViewEncapsulation,ViewChild, ElementRef} from '@angular/core';
import { ActivatedRoute, Router,
  Event as NavigationEvent,NavigationStart
 } from "@angular/router";
 import { filter } from "rxjs/operators";

declare var require: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.None,
 
})
export class AppComponent implements OnInit {
  public showLoader = false;

  @Input() appComponentDetail: any;

  ngOnInit() { }

   // I initialize the app component.
   constructor(private router: Router  ) {
 
  

}

}
