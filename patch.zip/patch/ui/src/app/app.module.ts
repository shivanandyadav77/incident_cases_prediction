import { BrowserModule, DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatePipe, DecimalPipe } from '@angular/common';
import { HTTP_INTERCEPTORS,HttpClientModule } from '@angular/common/http';
import {SanitizeHtmlPipe} from "./SanitizeHtmlPipe";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {IncidentServices}  from './shared/IncidentServices.service';
import {EnvironmentService} from './shared/environment.service'
import {DbserviceService} from './shared/dbservice.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { IncidentcasesComponent } from './incidentcases/incidentcases.component';
import { GoogleChartsModule } from 'angular-google-charts';
import { NgxLoadingModule } from 'ngx-loading';

@NgModule({
  declarations: [
    AppComponent,    
    IncidentcasesComponent,
    SanitizeHtmlPipe
    
  ],
  imports: [
    
    BrowserModule,   
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    // GoogleChartsModule.forRoot(),
    GoogleChartsModule,
    NgxLoadingModule.forRoot({}),  
    
  ],
  providers: [EnvironmentService,DatePipe,IncidentServices,DbserviceService    
    ],
  bootstrap: [AppComponent]
})
export class AppModule { }
