import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {IncidentcasesComponent} from './incidentcases/incidentcases.component'


const routes: Routes = [  
  { path: '',component:IncidentcasesComponent, pathMatch: 'full' }, 
  { path: '**', redirectTo: '/Main', pathMatch: 'full' }, 
  { path: 'incident', redirectTo: '/Main', pathMatch: 'full' }, 
  { path: 'incident/Main',component:IncidentcasesComponent, pathMatch: 'full' }, 
  { path: 'Main',component:IncidentcasesComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }