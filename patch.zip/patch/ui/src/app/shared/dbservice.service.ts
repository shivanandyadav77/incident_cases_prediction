import { Injectable } from '@angular/core';
import {HttpClient, HttpParams,HttpHeaders} from "@angular/common/http";
import 'rxjs/Rx';
import { map } from "rxjs/operators";
import {IncidentServices}  from './IncidentServices.service'
import {EnvironmentService} from '../shared/environment.service'
import {MonthlyPredictionData} from '../model/MonthlyPredictionData'
import {WeeklylyPredictionData} from '../model/WeeklyPredictionData'



@Injectable({
  providedIn: 'root'
})
export class DbserviceService {

  BASE_URL=this.envService.getUrl()  
  API_BASE_URL=this.BASE_URL.API_URL
  constructor(private http: HttpClient,
    private incidentService :IncidentServices,
    private  envService :EnvironmentService
  ) { }

  getMonthlyPrediction() 
  {   
    console.log("------------getMonthlyPrediction---------started")
    this.http.get<MonthlyPredictionData[]>('http://127.0.0.1:5000/monthlypredictiondata')
    .pipe(map(
      (ldata) => { 
        return ldata; ;
      }
    ))
    .subscribe(
      (lodata) => {   
        let closedata=[] 
        let opendata=[] 

        for (let rowdata of lodata)
        {
          let odata=[]
          let cdata=[]
          odata.push(rowdata.Incident_Created_On)
          odata.push(rowdata.M_Open_cases)
          odata.push(rowdata.M_Open_pred_data)
          opendata.push(odata)

          cdata.push(rowdata.Incident_Created_On)
          cdata.push(rowdata.M_Closed_cases)
          cdata.push(rowdata.M_Closed_pred_data)
          closedata.push(cdata)
        }
        console.log(opendata)
        console.log(closedata)
        this.incidentService.setlistMonthlyOpenInfo(opendata)
        this.incidentService.setListMonthlyCloseInfo(closedata)
  
      }
    );
  }

  getWeeklyPrediction() 
  {   
    
    this.http.get<WeeklylyPredictionData[]>('http://127.0.0.1:5000/weeklypredictiondata')
    .pipe(map(
      (ldata) => { 
        return ldata; ;
      }
    ))
    .subscribe(
      (lodata) => {   
        let closedata=[] 
        let opendata=[] 

        for (let rowdata of lodata)
        {
          let odata=[]
          let cdata=[]
          odata.push(rowdata.Incident_Created_On)
          odata.push(rowdata.W_Open_cases)
          odata.push(rowdata.W_Open_pred_data)
          opendata.push(odata)

          cdata.push(rowdata.Incident_Created_On)
          cdata.push(rowdata.W_Closed_cases)
          cdata.push(rowdata.W_Closed_pred_data)
          closedata.push(cdata)
        }
        this.incidentService.setlistWeeklyOpenInfo(opendata)
        this.incidentService.setListWeeklyCloseInfo(closedata)
  
      }
    );
  }



}