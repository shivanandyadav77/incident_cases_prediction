import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import{Users} from '../model/Users'
import{accessToken} from '../model/accessToken'
import {MonthlyPredictionData} from '../model/MonthlyPredictionData'

@Injectable({
  providedIn: 'root'
})
export class IncidentServices {



  private listMonthlyOpenInfo:any[];
  listMonthlyOpenChanged = new Subject<any[]>();

  private listMonthlyCloseInfo:any[];
  listMonthlyCloseChanged = new Subject<any[]>();

  private listWeeklyOpenInfo:any[];
  listWeeklyOpenChanged = new Subject<any[]>();

  private listWeeklyCloseInfo:any[];
  listWeeklyCloseChanged = new Subject<any[]>();


  islogoutFlag = true
  constructor() {}


  setlistMonthlyOpenInfo(imgData:any[]){
    this.listMonthlyOpenInfo=imgData;
    this.listMonthlyOpenChanged.next(this.listMonthlyOpenInfo);
  }
  getlistMonthlyOpenInfo(){
    return this.listMonthlyOpenInfo;
  }

  setListMonthlyCloseInfo(imgData:any[]){
    this.listMonthlyCloseInfo=imgData;
    this.listMonthlyCloseChanged.next(this.listMonthlyCloseInfo);
  }
  getListMonthlyCloseInfo(){
    return this.listMonthlyCloseInfo;
  }

  setlistWeeklyOpenInfo(imgData:any[]){
    this.listWeeklyOpenInfo=imgData;
    this.listWeeklyOpenChanged.next(this.listWeeklyOpenInfo);
  }
  getlistWeeklyOpenInfo(){
    return this.listWeeklyOpenInfo;
  }

  setListWeeklyCloseInfo(imgData:any[]){
    this.listWeeklyCloseInfo=imgData;
    this.listWeeklyCloseChanged.next(this.listWeeklyCloseInfo);
  }
  getListWeeklyCloseInfo(){
    return this.listWeeklyCloseInfo;
  }


}
