import { Injectable } from '@angular/core';
import 'rxjs/Rx';

@Injectable({
  providedIn: 'root'
})
export class EnvironmentService {

    host:String = window.location.host;

    getUrl()
    {     
        console.log("Windows host::"+this.host) 
        switch(this.host) { 
            case "localhost:4200": {                 

                var   auth= {
                    API_URL:  'http://localhost:8080/',
                    TOKEN_URL: 'https://cloudsso-test.cisco.com/as/token.oauth2?client_id=sst-nprd-api-client-id&client_secret=sstnprdclientid&grant_type=client_credentials',
                    SERVER_TYPE:'LOCAL'
  
                }

                console.log("control in local host block")
                return auth
            } 
            case "sst-client-dev.cisco.com": { 
                
                var   auth= {
                    API_URL:  'https://sst-dev.cisco.com/selfservicetool/',
                    TOKEN_URL: 'https://cloudsso-test.cisco.com/as/token.oauth2?client_id=sst-nprd-api-client-id&client_secret=sstnprdclientid&grant_type=client_credentials',
                    SERVER_TYPE:'DEV'
                }
                return auth
            } 
            case "sst-client-stg.cisco.com": { 
                
                
                var   auth= {
                    API_URL: 'https://sst-stg.cisco.com/selfservicetool/',
                    TOKEN_URL: 'https://cloudsso-test.cisco.com/as/token.oauth2?client_id=sst-nprd-api-client-id&client_secret=sstnprdclientid&grant_type=client_credentials',
                    SERVER_TYPE:'STG'
                   
                }
                return auth
                
            } 
            case "sst-client-lt.cisco.com": { 
                

                var   auth= {
                    API_URL:'https://sst-lt.cisco.com/selfservicetool/',
                    TOKEN_URL: 'https://cloudsso-test.cisco.com/as/token.oauth2?client_id=sst-nprd-api-client-id&client_secret=sstnprdclientid&grant_type=client_credentials',
                    SERVER_TYPE:'LT'
                }

                return auth
            } 
            case "sst-client-cloud.cisco.com": { 
                

                var   auth= {
                    API_URL:'https://sst-api-cloud.cisco.com/selfservicetool/',
                    TOKEN_URL: 'https://cloudsso.cisco.com/as/token.oauth2?client_id=sst-prod-api-ouath-client-id&client_secret=sstprdoauthsecretkey&grant_type=client_credentials',
                    SERVER_TYPE:'PROD'
                }
                   
                return auth
            } 
            default : { 
                

                var auth= {
                    API_URL: 'http://localhost:8080/',
                    TOKEN_URL: 'https://cloudsso-test.cisco.com/as/token.oauth2?client_id=sst-nprd-api-client-id&client_secret=sstnprdclientid&grant_type=client_credentials',
                    SERVER_TYPE:'LOCAL'
                }
               
                return auth

            } 
         } 
    }
}