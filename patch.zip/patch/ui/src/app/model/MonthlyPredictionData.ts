export interface MonthlyPredictionData {
    Incident_Created_On: string;
    M_Open_pred_data: number;
    M_Open_cases: number;
    M_Closed_cases: number;
    M_Closed_pred_data: number;
}