import {UserDetails} from './UserDetails'
export class Users {
    errorMessage: string;
    userDetails: UserDetails[];
    constructor(errorMessage:string,userDetails:UserDetails[])
    {
        this.errorMessage=errorMessage;
        this.userDetails=userDetails;

    }
}