export class UserDetails {
    personName: string;
    userRoles: string;
    userEmail: string;
    empNumber: number;
}