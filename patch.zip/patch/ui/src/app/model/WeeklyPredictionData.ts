export interface WeeklylyPredictionData {
    Incident_Created_On: string;
    W_Open_pred_data: number;
    W_Open_cases: number;
    W_Closed_pred_data: number;
    W_Closed_cases: number;
}