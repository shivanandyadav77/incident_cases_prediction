
export class accessToken {
    access_token:any
    token_type:any
    expires_in:number
    timestamp:number
    userId:any
    constructor(access:any,token:any,expires:any){
       this.access_token=access
    this.token_type=token
    this.expires_in=expires
       
    }
}