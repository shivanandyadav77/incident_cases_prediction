import {
  Component,
  Input,
  OnInit,Inject,
} from "@angular/core";

import { ActivatedRoute, Router } from "@angular/router";
import { IncidentServices } from "../shared/IncidentServices.service";
import { DbserviceService } from "../shared/dbservice.service";
import { Subscription } from "rxjs";
import { Users } from "../model/Users";
import{accessToken} from '../model/accessToken'
import { NgForm } from "@angular/forms";
import {FormGroup, FormControl, Validators}  from '@angular/forms';
import "rxjs/Rx";
import { Observable } from "rxjs";
import { mapTo, delay } from "rxjs/operators";
import {EnvironmentService} from "../shared/environment.service"

@Component({
  selector: 'app-incidentcases',
  templateUrl: './incidentcases.component.html',
  styleUrls: ['./incidentcases.component.css']
})
export class IncidentcasesComponent implements OnInit {

  predictionType=['Weekly','Monthly']
  selectedpredictionType:any='Weekly'
  weekly_title = 'Weekly Incident cases prediction chart';
  monthly_title = 'Monthly Incident cases prediction chart';
  type = 'LineChart';

  columnNames = ["Month", "Tokyo", "New York","Berlin", "Paris"];
  monthly_options = {   
    hAxis: {
      title: 'Months',
      textStyle:{
         color:'#01579b',
         fontSize:16,
         fontName:'Arial',
         bold:false,
         italic:true
      }
   },
   vAxis:{
      title: 'No Of Incident cases', textStyle:{
         color:'#01579b',
         fontSize:16,
         fontName:'Arial',
         bold:false,
         italic:true
      }
   }, 
//    series: {
//     0: { lineWidth: 10, lineDashStyle: [5, 1, 5] },
//     1: { lineWidth: 5, lineDashStyle: [7, 2, 4, 3] }            
//  },
//  curveType: 'function', 
//  legend: { position: 'bottom' },
   crosshair:{
    color:'#000000',
    trigger:'selection'  
   }, 
   pointSize:5,
   backgroundColor:'#f1f8e9',
   colors:["#a52714", "#0000ff", "#ff0000", "#00ff00"]
  };

  weekly_options = {   
    hAxis: {
      title: 'Weeks',
      textStyle:{
         color:'#01579b',
         fontSize:16,
         fontName:'Arial',
         bold:false,
         italic:true
      }
   },
   vAxis:{
      title: 'No Of Incident cases', textStyle:{
         color:'#01579b',
         fontSize:16,
         fontName:'Arial',
         bold:false,
         italic:true
      }
   }, 
//    series: {
//     0: { lineWidth: 10, lineDashStyle: [5, 1, 5] },
//     1: { lineWidth: 5, lineDashStyle: [7, 2, 4, 3] }            
//  },
//  curveType: 'function', 
//  legend: { position: 'bottom' },
   crosshair:{
    color:'#000000',
    trigger:'selection'  
   }, 
   pointSize:5,
   backgroundColor:'#f1f8e9',
   colors:["#a52714", "#0000ff", "#ff0000", "#00ff00"]
  };

  width = 1500;
  height = 500;

  //ng forms
  formobj: NgForm;

 
  // monthly open 
  listMonthlyOpenSubscription: Subscription;
  lsitMonthlyOpenPreddata: any[];

  
  // monthly close 
  listMonthlyCloseSubscription: Subscription;
  lsitMonthlyClosePreddata: any[];

  // weekly open 
  listWeeklyOpenSubscription: Subscription;
  lsitWeeklyOpenPreddata: any[];

  
  // weekly close 
  listWeeklyCloseSubscription: Subscription;
  lsitWeeklyClosePreddata: any[];



  // user data
  userSubscription: Subscription;
  userData: Users;


  constructor(  
    private commonService: IncidentServices,
    private dbService: DbserviceService,    
    private  envService :EnvironmentService
  ) {}


  ngOnInit() {

    let BASE_URL=this.envService.getUrl()
    document.body.style.zoom = "75%";
    this.lsitMonthlyOpenPreddata=null;  
    this.lsitMonthlyClosePreddata=null; 
    this.lsitWeeklyOpenPreddata=null;
    this.lsitWeeklyClosePreddata=null;
 
    // get monthly open cases  data----   
    this.listMonthlyOpenSubscription = this.commonService.listMonthlyOpenChanged.subscribe(
      (mdata:any[]) => {  
        this.lsitMonthlyOpenPreddata=mdata;        
    }); 

    // get monthly close cases  data----   
    this.listMonthlyCloseSubscription = this.commonService.listMonthlyCloseChanged.subscribe(
      (mdata:any) => {  
       this.lsitMonthlyClosePreddata=mdata;        
    }); 

    
    ///

     // get weekly open cases  data----   
     this.listWeeklyOpenSubscription = this.commonService.listWeeklyOpenChanged.subscribe(
      (mdata:any[]) => {  
        this.lsitWeeklyOpenPreddata=mdata;        
    }); 

    // get weekly close cases  data----   
    this.listWeeklyCloseSubscription = this.commonService.listWeeklyCloseChanged.subscribe(
      (mdata:any) => {  
       this.lsitWeeklyClosePreddata=mdata;        
    }); 


    this.dbService.getWeeklyPrediction()
    // this.dbService.getMonthlyPrediction()

  
  }//ngOnit end

  public selectPredictionType(event)
  {
    this.lsitMonthlyOpenPreddata=null;  
    this.lsitMonthlyClosePreddata=null; 
    this.lsitWeeklyOpenPreddata=null;
    this.lsitWeeklyClosePreddata=null;
 
    console.log("prediction type::"+this.selectedpredictionType)
    if (this.selectedpredictionType=='Weekly') 
    {
      // this.showLoader = true;
      console.log("controller came in weekly")
      this.dbService.getWeeklyPrediction()
      
      
    } else if (this.selectedpredictionType=='Monthly')  {
      // this.showLoader = false;
      console.log("controller came in monthly")
      this.dbService.getMonthlyPrediction()
    }
    

  }

}
