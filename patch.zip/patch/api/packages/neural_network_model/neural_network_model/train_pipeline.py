from sklearn.externals import joblib
import logging
from sklearn.preprocessing import MinMaxScaler

from neural_network_model import pipeline as pipe
from neural_network_model.config import config
from neural_network_model.processing import data_management as dm
from neural_network_model.processing import preprocessors as pp

_logger = logging.getLogger(__name__)

def run_training(save_result: bool = True):
    """Train a Convolutional Neural Network."""

    _logger.info(f'folder path: {config.DATASET_DIR}')
    df=pp.load_data(config.DATASET_DIR)
    open_weekly_df=pp.open_weekly_prediction(df)
    print(open_weekly_df)  
    

    

       





if __name__ == '__main__':
    run_training(save_result=True)
