import numpy as np
from keras.utils import np_utils
from sklearn.preprocessing import LabelEncoder
from sklearn.base import BaseEstimator, TransformerMixin


# import xlrd
import pandas as pd
# pd.options.display.max_columns = None
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LSTM , Dropout
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.preprocessing.sequence import TimeseriesGenerator
from tensorflow.keras.layers import Bidirectional


import warnings
warnings.filterwarnings("ignore")


def load_data(data_folder: str) -> pd.DataFrame:
    data = pd.read_excel(data_folder)
    df = data.copy()
    df.rename(columns=df.iloc[1],inplace=True)
    df = df.iloc[3:,1:]
    df.index = range(len(df))
    print(df.columns)
    return df


def prepareDataset(df:pd.DataFrame,period:str,dateField:str):
    incident_open = df[[dateField]]
    incident_open['cases'] = 1
    incident_date = incident_open[dateField].dt.to_period(period)
    incidentDF = incident_open.groupby(incident_date).sum()[:-1]
    return incidentDF

def train_test_split(data,scale):
    train = data[:int((len(data)+1)*.80)]
    test = data[int((len(data))*.80+1):]
    scale.fit(train)
    train_scale = scale.transform(train)
    test_scale = scale.transform(test)    
    return train_scale,test_scale


def modeling(train_scale,no_epoch,n_input_train_data,n_feature_train_data):
    
    generator = TimeseriesGenerator(train_scale,train_scale,length=2,batch_size=3)
    model = Sequential()
    model.add(Bidirectional(LSTM(500,activation='sigmoid',input_shape=(n_input_train_data,n_feature_train_data),return_sequences=True)))
    model.add(Bidirectional(LSTM(400,activation='sigmoid')))       
    model.add(Dense(1))    
    model.compile(optimizer='adam',loss=['mse'])    
    model.fit_generator(generator,epochs=no_epoch)    
    return model 


def prediction(model,test_scale,no_predictions,n_input_test,n_feature_test,scale):
    
    model_pred_scale = []
    reshaped_data = test_scale.reshape((1,n_input_test+1,n_feature_test))     
    for x in range(len(test_scale)+no_predictions):
        pred = model.predict(reshaped_data)[0]        
        model_pred_scale.append(pred)        
        reshaped_data = np.append(reshaped_data[:,1:],[[pred]],axis=1)        


    pred = scale.inverse_transform(model_pred_scale)

    return pred     

def open_weekly_prediction(df):
    period='W'
    dateField="Incident Created On"
    no_pred_open=3
    weekly_epoch=10
    scale = MinMaxScaler()
    opened = prepareDataset(df,period,dateField)
    Open_train_scale, Open_test_scale = train_test_split(opened,scale)
    n_input_test= Open_test_scale.shape[0]-1
    n_feature_test = Open_test_scale.shape[1]

    n_input_train= Open_train_scale.shape[0]-1
    n_feature_train = Open_train_scale.shape[1]

    open_model = modeling(Open_train_scale,weekly_epoch,n_feature_train,n_feature_train)
    
    open_model_predictions = prediction(open_model,Open_test_scale,no_pred_open,n_input_test,n_feature_test,scale)

    FinalDF = pd.DataFrame(open_model_predictions.reshape(-1)[:-no_pred_open],columns=['Open_pred_data'])
    FinalDF.index = opened.index[-len(Open_test_scale):]
    FinalDF['Open_cases'] = opened[-len(Open_test_scale):]

    return FinalDF

def close_weekly_prediction(df):
    period='W'
    dateField="Incident Resolved at"
    no_pred_open=3
    weekly_epoch=10

    scale = MinMaxScaler()

    closed = prepareDataset(df,period,dateField)

    closed_train_scale, closed_test_scale = train_test_split(closed)

    n_input_test_closed= closed_test_scale.shape[0]-1
    n_feature_test_closed = closed_test_scale.shape[1]

    n_input_train_closed= closed_train_scale.shape[0]-1
    n_feature_train_closed = closed_train_scale.shape[1]


    


